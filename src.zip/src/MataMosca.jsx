import React, { useEffect, useRef, useState } from "react";
import virusImg from "./img/virus.png";
import "./style/MataMosca.css";

export default function MataMosca({ path, onComplete, onBack, backButtonStyle }) {
  const [moscas, setMoscas] = useState([]);
  const [lives, setLives] = useState(3);
  const [timeLeft, setTimeLeft] = useState(30);
  const [score, setScore] = useState(0);
  const [running, setRunning] = useState(true);

  const spawnRef = useRef(null);
  const timerRef = useRef(null);
  const areaRef = useRef(null);
  const idCounter = useRef(0);

  const GAME_TIME = 30;
  const SPAWN_INTERVAL = 1200;
  const MAX_MOSCAS = 1;

  const startGame = () => {
    clearInterval(spawnRef.current);
    clearInterval(timerRef.current);

    idCounter.current = 0;
    setTimeLeft(GAME_TIME);
    setLives(3);
    setScore(0);
    setMoscas([]);
    setRunning(true); // 🔹 precisa estar true ANTES dos timers

    // Timer ⏱️
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current);
          setRunning(false);
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    // Spawn de moscas 🦟
    spawnRef.current = setInterval(() => {
      setMoscas((cur) => {
        if (!areaRef.current) return cur;
        if (cur.length >= MAX_MOSCAS) return cur;

        const rect = areaRef.current.getBoundingClientRect();
        const margin = 40;
        const x = Math.max(margin, Math.random() * (rect.width - margin * 2));
        const y = Math.max(margin, Math.random() * (rect.height - margin * 2));
        idCounter.current += 1;
        const size = 36 + Math.floor(Math.random() * 36);

        return [{ id: "m" + idCounter.current, x, y, size }];
      });
    }, SPAWN_INTERVAL);
  };

  useEffect(() => {
    startGame();
    return () => {
      clearInterval(spawnRef.current);
      clearInterval(timerRef.current);
    };
  }, []);

  // Se a mosca não for clicada → perde 1 vida
  useEffect(() => {
    if (!running || moscas.length === 0) return;

    const t = setTimeout(() => {
      setMoscas([]);
      setLives((lv) => {
        const n = lv - 1;
        if (n <= 0) stopGame(false);
        return n;
      });
    }, 2000);

    return () => clearTimeout(t);
  }, [moscas, running]);

  const stopGame = (win) => {
    setRunning(false);
    clearInterval(spawnRef.current);
    clearInterval(timerRef.current);

    if (win) {
      window.dispatchEvent(new CustomEvent("xp:add", { detail: 50 }));
      window.dispatchEvent(new CustomEvent("coins:add", { detail: 20 }));
      window.dispatchEvent(new CustomEvent("badge:add", { detail: "Caçador de Moscas" }));
      setTimeout(() => onComplete && onComplete(), 600);
    }
  };

  const killMosca = (id) => {
    setMoscas([]);
    setScore((s) => {
      const newScore = s + 1;
      if (newScore >= 12) stopGame(true);
      return newScore;
    });
  };

  const resetGame = () => {
    idCounter.current = 0;
    startGame();
  };

  return (
    <div
      ref={areaRef}
      className={`mata-mosca-container ${path === "armazenamento" ? "bg-armazenamento" : "bg-seguranca"}`}
    >
      {/* HUD sempre visível */}
      <div className="hud">
        <div className="hud-left">
          <div className="hud-title">Mata-Mosca</div>
          <div>⏱️ {timeLeft}</div>
          <div>💥 {score}</div>
          <div>❤️ {lives}</div>
        </div>
        <div className="hud-buttons">
          <button onClick={onBack} style={backButtonStyle || {}}>
            ⬅️ Voltar
          </button>
          <button onClick={resetGame} className="restart-button">
            Reiniciar
          </button>
        </div>
      </div>

      {/* Área de jogo */}
      <div className="game-area">
        {moscas.map((m) => (
          <img
            key={m.id}
            src={virusImg}
            alt="mosca"
            onClick={() => killMosca(m.id)}
            className="mosca"
            style={{ left: m.x, top: m.y, width: m.size, height: m.size }}
          />
        ))}

        {/* Game Over */}
        {!running && lives <= 0 && (
          <div className="overlay">
            <h2>💀 Game Over</h2>
            <button onClick={onBack} className="overlay-button red">
              🔙 Voltar ao início
            </button>
          </div>
        )}

        {/* Tempo esgotado */}
        {!running && timeLeft === 0 && (
          <div className="overlay">
            <h2>⏰ Tempo esgotado</h2>
            <button onClick={onBack} className="overlay-button blue">
              🔙 Voltar ao início
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
